package com.chinasofti.machinelearning.spamdetermination.client;

import com.chinasofti.platform.rpc.Service;
import com.chinasofti.spamdetermination.rpcserver.bizinterface.ISpamDeterminationBiz;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ISpamDeterminationBiz biz = (ISpamDeterminationBiz) Service.lookup("192.168.1.101", "service");
		//biz.reMR();
		System.out.println(biz.isSpam("Hello us"));
	}

}
