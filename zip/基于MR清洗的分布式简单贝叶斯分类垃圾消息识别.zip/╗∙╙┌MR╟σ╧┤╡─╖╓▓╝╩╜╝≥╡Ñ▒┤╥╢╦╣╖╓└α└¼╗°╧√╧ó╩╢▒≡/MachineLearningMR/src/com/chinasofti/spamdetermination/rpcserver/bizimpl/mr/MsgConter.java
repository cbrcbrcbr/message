package com.chinasofti.spamdetermination.rpcserver.bizimpl.mr;

public enum MsgConter {
	ConterHam,ConterSpam
}
